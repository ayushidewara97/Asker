package com.example.win81.asker;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView login,signup;
    FragmentManager fm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = (TextView) findViewById(R.id.login);
        signup = (TextView) findViewById(R.id.signup);
        fm = getSupportFragmentManager();

        //fm.beginTransaction().add(R.id.framelayout,new LoginFrag()).commit();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //fm.beginTransaction().replace(R.id.framelayout,new LoginFrag()).commit();
                Toast.makeText(getBaseContext(),"this is working ",Toast.LENGTH_SHORT).show();

            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm.beginTransaction().replace(R.id.framelayout,new SignupFrag()).commit();

            }
        });

    }
}
